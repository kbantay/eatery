-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2025 at 05:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eatery_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `menus_tbl`
--

CREATE TABLE `menus_tbl` (
  `menu_id` int(7) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `mdesc` varchar(255) NOT NULL,
  `mcat` varchar(50) NOT NULL,
  `mprice` int(7) NOT NULL,
  `mstock` int(7) DEFAULT NULL,
  `isBestSeller` int(1) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menus_tbl`
--

INSERT INTO `menus_tbl` (`menu_id`, `mname`, `mdesc`, `mcat`, `mprice`, `mstock`, `isBestSeller`, `img`) VALUES
(1, 'Sizzling Sisig', 'Composed of minced pork, chopped onion, and chicken liver', 'Ulam', 89, 20, 1, 'sisig.jpg'),
(2, 'Pork Adobo', 'Pork cooked in soy sauce, vinegar, and garlic.', 'Ulam', 78, 20, 0, 'adobo.jpg'),
(3, 'Chicken Tinola', 'Soup made with chicken, chayote squash, bok choy, and spinach, features a savory broth flavored with ginger', 'Ulam', 79, 20, 0, 'tinola.jpg'),
(4, 'Buko Juice', 'An iced cold fresh coconut juice', 'Drinks', 45, 10, 0, 'buko.jpg'),
(5, 'Mango Shake', 'An ice blended mango drink made with fresh mangoes and evaporated milk.', 'Drinks', 65, 10, 1, 'mango.jpg'),
(6, 'Leche Flan', 'A creamy caramel dessert made with egg yolks, milk, sugar, and vanilla extract', 'Dessert', 85, 8, 0, 'lecheflan.jpg'),
(7, 'Buko Salad', 'A shredded young coconut salad with thick cream and condensed milk with jellies', 'Dessert', 85, 15, 1, 'bukosalad.jpg'),
(9, 'kaldereta', 'Variations of the dish use beef, chicken, or pork. Commonly, the goat meat is stewed with vegetables and liver paste. Vegetables may include tomatoes, potatoes, olives, bell peppers, and hot peppers. Kaldereta sometimes includes tomato sauce.', 'Ulam', 95, 15, 1, 'caldereta.jpg'),
(12, 'hotsilog', 'hotdog at itlog', 'Ulam', 60, 20, 0, 'hotsilog.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems_tbl`
--

CREATE TABLE `orderitems_tbl` (
  `orderitemid` int(7) NOT NULL,
  `order_id` int(7) NOT NULL,
  `itemname` varchar(200) NOT NULL,
  `price` int(7) NOT NULL,
  `quantity` int(7) NOT NULL,
  `subtotal` int(7) NOT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_tbl`
--

CREATE TABLE `order_tbl` (
  `order_id` int(7) NOT NULL,
  `ordermap_id` int(7) DEFAULT NULL,
  `totalprice` int(7) DEFAULT NULL,
  `orderstatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_tbl`
--

INSERT INTO `order_tbl` (`order_id`, `ordermap_id`, `totalprice`, `orderstatus`) VALUES
(1, NULL, NULL, 'Ordering'),
(2, NULL, NULL, 'Ordering'),
(3, NULL, NULL, 'Ordering'),
(4, NULL, NULL, 'Ordering'),
(5, NULL, NULL, 'Ordering'),
(6, NULL, NULL, 'Ordering'),
(7, NULL, NULL, 'Ordering'),
(8, NULL, NULL, 'Ordering'),
(9, NULL, NULL, 'Ordering'),
(10, NULL, NULL, 'Ordering'),
(11, NULL, NULL, 'Ordering'),
(12, NULL, NULL, 'Ordering'),
(13, NULL, NULL, 'Ordering');

-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE `users_tbl` (
  `user_id` int(7) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `firstname`, `surname`, `username`, `password`, `role`) VALUES
(1, 'Tony', 'Stark', 'admin', '$2y$12$485PaVYctvwOPlwVKhboLOocYfIpaNh7t1G2/tafKubGTdbz8.sJS', 'admin'),
(2, 'khelsey', 'bantay', 'khels', '$2y$12$9jpEqcXG5pqY8tVzhAyzO.G1gZ84PAmrh28zfz7ahGK6ajXfGYe5O', 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menus_tbl`
--
ALTER TABLE `menus_tbl`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `orderitems_tbl`
--
ALTER TABLE `orderitems_tbl`
  ADD PRIMARY KEY (`orderitemid`);

--
-- Indexes for table `order_tbl`
--
ALTER TABLE `order_tbl`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menus_tbl`
--
ALTER TABLE `menus_tbl`
  MODIFY `menu_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orderitems_tbl`
--
ALTER TABLE `orderitems_tbl`
  MODIFY `orderitemid` int(7) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_tbl`
--
ALTER TABLE `order_tbl`
  MODIFY `order_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `user_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
